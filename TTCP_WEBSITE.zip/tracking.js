const shipments={
"TTCP123456":{status:"Pending Verification",location:"International Hub"},
"TTCP654321":{status:"Delivered",location:"Recipient Address"}
};

const aiText={
"Pending Verification":"Your shipment is undergoing routine verification. Customer Care can assist.",
"Delivered":"Your shipment has been successfully delivered."
};

function trackShipment(){
const num=document.getElementById("tracking-number").value;
const out=document.getElementById("tracking-output");
const ai=document.getElementById("assistant-text");

if(!shipments[num]){
out.innerHTML="Tracking number not found.";
ai.innerText="Please contact customer support for assistance.";
return;
}

out.innerHTML="Status: "+shipments[num].status+"<br>Location: "+shipments[num].location;
ai.innerText=aiText[shipments[num].status];
}
